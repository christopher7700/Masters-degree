
from mrjob.job import MRJob

def rango_edad(c):

    if  c == 'DESCONOCIDA' :
        return(-1,-1)
    
    elif c == 'MAYOR DE 74':
        return(75,100) 
    

    else:
        if  c != 'DESCONOCIDA' or 'MAYOR DE 74' :
            numbers = []
        for word in c.split():
            if word.isdigit():
                numbers.append(int(word))
        return(numbers)
    

def lesividad(c):

    if c == "" :
        return(0)
    elif c== "LESIVIDAD*":
        next
        #return([])
    else:
        return(int(c))



class MRWordFrequencyCount(MRJob):
    import pandas as pd
    
    def mapper(self, key, line):

        line=line.strip()
        row=line.split(";")
        r_edad= rango_edad(row[10].split(" A\u00d1OS")[0])
        lesi=lesividad(row[12])

        yield r_edad,lesi

    def reducer(self, r_edad, values):

        item_count = 0
        item_sum = 0
        for lesi in values:
            item_count += 1
            
            if lesi==4:
                item_sum+=1
        if r_edad != []:
            if r_edad != [-1,-1]:
                yield r_edad, (item_count,item_sum)
         
if __name__ == '__main__':
    MRWordFrequencyCount.run()
    